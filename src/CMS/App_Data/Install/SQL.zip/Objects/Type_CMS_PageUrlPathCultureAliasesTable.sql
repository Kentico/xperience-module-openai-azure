CREATE TYPE [dbo].[Type_CMS_PageUrlPathCultureAliasesTable] AS TABLE(
	[CultureCode] [nvarchar](50) NOT NULL,
	[CultureAlias] [nvarchar](100) NULL
)
GO
