SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_WebFarmTask_DeleteOrphanedTasks]
	@deleteTaskCount int,
	@deleteOlderThan datetime2,
	@deleteBindings bit

AS
BEGIN
	SET NOCOUNT ON;

	IF (@deleteBindings = 1)
	BEGIN
		-- Delete server tasks that are violating foreign key policy because of nolocks in inserting servertaks
		DELETE FROM [CMS_WebFarmServerTask] WHERE [ServerID] NOT IN (SELECT [ServerID] FROM [CMS_WebFarmServer])
	END

	-- Delete old tasks that were already processed
	DELETE TOP(@deleteTaskCount) FROM [CMS_WebFarmTask] WHERE [TaskIsAnonymous] = 0 AND [TaskID] NOT IN (SELECT DISTINCT [TaskID] FROM [CMS_WebFarmServerTask]) AND [TaskCreated] < @deleteOlderThan

	-- Return number of deleted tasks
	SELECT @@ROWCOUNT
END
GO
