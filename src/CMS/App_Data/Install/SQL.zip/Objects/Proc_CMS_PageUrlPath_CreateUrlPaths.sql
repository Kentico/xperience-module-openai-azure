SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Proc_CMS_PageUrlPath_CreateUrlPaths]
	@NodeID INT,
	@SiteID INT,
	@LastModified DATETIME,
	@UrlPaths Type_CMS_PageUrlPathsTable READONLY
AS
BEGIN
    BEGIN TRANSACTION
		BEGIN TRY
			INSERT INTO [CMS_PageUrlPath]([PageUrlPathLastModified], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathGUID])
			SELECT @LastModified, CultureCode, @NodeID, UrlPath, CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', LOWER(UrlPath)), 2) ,@SiteID, NEWID() 
			FROM @UrlPaths
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
				DECLARE @PathsToInsert AS Type_CMS_PageUrlPathsTable
				DECLARE @NodeGUID AS NVARCHAR(36) = CONVERT(NVARCHAR(36), (SELECT TOP 1 [NodeGUID] FROM [CMS_Tree] WHERE [NodeID] = @NodeID))

				INSERT INTO @PathsToInsert 
				SELECT * FROM @UrlPaths

				UPDATE CollidingItem
					SET CollidingItem.UrlPath = CollidingItem.UrlPath + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER(CollidingItem.UrlPath + CollidingItem.CultureCode + @NodeGUID)), 2))
					FROM @PathsToInsert AS CollidingItem
					INNER JOIN [CMS_PageUrlPath] AS PageUrlPath 
						ON PageUrlPath.PageUrlPathUrlPathHash = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(CollidingItem.UrlPath)), 2) AND PageUrlPath.PageUrlPathCulture =  CollidingItem.CultureCode
						WHERE PageUrlPath.PageUrlPathSiteID = @SiteID

				UPDATE CollidingItem
					SET CollidingItem.UrlPath = CollidingItem.UrlPath + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER(CollidingItem.UrlPath + CollidingItem.CultureCode + @NodeGUID)), 2))
					FROM @PathsToInsert AS CollidingItem
					INNER JOIN [CMS_AlternativeUrl] AS AlternativeUrl
						ON AlternativeUrl.AlternativeUrlUrl = CollidingItem.UrlPath
						WHERE AlternativeUrl.AlternativeUrlSiteID = @SiteID AND LEN(CollidingItem.UrlPath) <= 450

				INSERT INTO [CMS_PageUrlPath]([PageUrlPathLastModified], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathGUID])
				SELECT @LastModified, CultureCode, @NodeID, UrlPath, CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(UrlPath)), 2), @SiteID, NEWID() 
				FROM @PathsToInsert
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END

		END CATCH	

		COMMIT TRANSACTION
END
GO
